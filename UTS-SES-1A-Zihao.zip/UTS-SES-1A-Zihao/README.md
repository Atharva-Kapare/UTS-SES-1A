# UTS-SES-1A
This is the repo for the app we had to make in SES 1A

# Topic
We were tasked to create a web-based application that would be used by doctors and patients in order to diagnose illnesses over the internet without in person interaction.

# For the Testers
* Test the functionality of the register page

# How To Use
Clone the github repo to your local device or download it. Double click on index.html, this will take you to the home page of the website from which you can go to the other pages, such as login or register. 

## Members
Atharva Kapare,
Himanshu Mehta,
Zihao Cui,
Ihtsham Shafiq,
Thai Seng Tha,
Zhibo Wang,
